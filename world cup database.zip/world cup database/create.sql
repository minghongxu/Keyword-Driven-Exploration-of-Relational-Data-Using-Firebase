
/*create table WorldCupMatches (
Year int(5), 
Datetime	 VARCHAR(40),
Stage	VARCHAR(40),
Stadium	VARCHAR(40),
City	VARCHAR(40),
`Home Team Name`	VARCHAR(40),
`Home Team Goals`	int(5), 
`Away Team Goals`	int(5), 
`Away Team Name`	VARCHAR(40),
`Win conditions`VARCHAR(40),
Attendance	VARCHAR(40),
`Half-time Home Goals` VARCHAR(40),
`Half-time Away Goals`	VARCHAR(40),
Referee VARCHAR(40),
`Assistant 1`	VARCHAR(40),
`Assistant 2`	VARCHAR(40),
RoundID	INT(11),
MatchID	INT(11),
`Home Team Initials`	VARCHAR(40),
`Away Team Initials` VARCHAR(40)
); 

create table WorldCupPlayers (
RoundID	INT,
MatchID	INT,
`Team Initials` VARCHAR(40),
`Coach Name` VARCHAR(40),
`Line-up` VARCHAR(40),
`Shirt Number`	INT,
`Player Name` VARCHAR(40),
Position VARCHAR(40),
Event VARCHAR(40)
); */

create table WorldCups(
Year INT,
Country VARCHAR(40),
Winner	 VARCHAR(40),
`Runners-Up`	VARCHAR(40),
Third VARCHAR(40),
Fourth	VARCHAR(40),
GoalsScored INT,
QualifiedTeams INT,
MatchesPlayed INT,
Attendance VARCHAR(40) 
)


