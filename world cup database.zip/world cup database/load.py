#!/usr/bin/env python
# coding: utf-8

import json
import csv
import requests
import pandas as pd
import re
import unicodedata
import sys
import os


csvfile1 = sys.argv[1]
csvfile2 = sys.argv[2]
csvfile3 = sys.argv[3]

'''
csvfile1 = 'city.csv'
csvfile2 = 'country.csv'
csvfile3 = 'countrylanguage.csv'
'''

#clean cvs
csvclean1 = 'clean'+csvfile1
f1 = open(csvfile1, encoding='Latin-1')
w1 = open(csvclean1, 'w', newline='')
spamwriter = csv.writer(w1)
for row in f1:
    p1 = re.compile('\'[a-zA-Z\s]+(,)\s[a-zA-Z\s.]+\'', re.S)  
    row_clean = re.sub(p1, "", row)
    spamwriter.writerow(row_clean.split(','))
f1.close()
w1.close()


csvclean2 = 'clean'+csvfile2
f2 = open(csvfile2, encoding='Latin-1')
w2 = open(csvclean2, 'w', newline='')
spamwriter = csv.writer(w2)
for row in f2:
    p1 = re.compile('\'[a-zA-Z\s]+(,)\s[a-zA-Z\s.]+\'', re.S)  
    row_clean = re.sub(p1, "", row)
    spamwriter.writerow(row_clean.split(','))
f2.close()
w2.close()

csvclean3 = 'clean'+csvfile3
f3 = open(csvfile3, encoding='Latin-1')
w3 = open(csvclean3, 'w', newline='')
spamwriter = csv.writer(w3)
for row in f3:
    p1 = re.compile('\'[a-zA-Z\s]+(,)\s[a-zA-Z\s.]+\'', re.S)  
    row_clean = re.sub(p1, "", row)
    spamwriter.writerow(row_clean.split(','))
f3.close()
w3.close()



#csv to json function
def csvtojson(csvpath, s):
    df = pd.read_table(csvpath, encoding='Latin-1', sep = s, skiprows = 0)
    l = []
    for key in df.keys():
        s = key.strip("[, \-!?:#$\./'\@&\()\,=\+\n]+")
        l.append(s)
    df.columns = l
    for key in df.keys():
        df[key] = df[key].str.strip(", \-!?:#$\./'\@&\()\,=\+\n")
    filejson = df.to_json(orient = 'records')
    return filejson




url = 'https://inf551-worldcup.firebaseio.com/'
url1 = url+csvfile1[: -3] + 'json'
url2 = url+csvfile2[: -3] + 'json'
url3 = url+csvfile3[: -3] + 'json'


cleanjson1 = csvtojson(csvclean1, ',')
cleanjson2 = csvtojson(csvclean2, ',')
cleanjson3 = csvtojson(csvclean3, ',')


response1 = requests.put(url1, cleanjson1)
response2 = requests.put(url2, cleanjson2)
response3 = requests.put(url3, cleanjson3)
print(response1)
print(response2)
print(response3)

os.remove(csvclean1)
os.remove(csvclean2)
os.remove(csvclean3)






#funtion to write index
def invert_index(jsonfile, primary_key, tablename):
    filepy = json.loads(jsonfile)
    for row in filepy:
        for key, v in row.items():
            if v is not None and re.search(r'[a-zA-Z]+', v) != None:
                v = v.lower()
                v = re.sub(r"[(\[),\-!?:#$\.\/'\@&\()\,=\+_\n(\])]+", ' ',v)
                value_list = v.split(' ')
                for value in value_list:
                    if len(value) != 0 and value != ' ':
                        d = {}
                        d['TABLE'] = tablename
                        d['COLUMN'] = key
                        d[primary_key] = row[primary_key]
                        if value not in indexed:
                            indexed[value] = [d]
                        else:
                            indexed[value].append(d)




key_dict = {'country': 'Code', 'city': 'ID', 'countrylanguage': 'Language'}
primary_key1 = key_dict[csvfile1[: -4]]
primary_key2 = key_dict[csvfile2[: -4]]
primary_key3 = key_dict[csvfile3[: -4]]

indexed = {}
invert_index(cleanjson1, primary_key1, csvfile1[: -4])
invert_index(cleanjson2, primary_key2, csvfile2[: -4])
invert_index(cleanjson3, primary_key3, csvfile3[: -4])



#index
url4 = 'https://inf551-hw1-be0b2.firebaseio.com/index.json'
indexjson = json.dumps(indexed)
response4 = requests.put(url4, indexjson)
print(response4)




