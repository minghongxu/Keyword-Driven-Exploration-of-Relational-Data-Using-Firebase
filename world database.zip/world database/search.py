#!/usr/bin/env python
# coding: utf-8



import json
import csv
import requests
import pandas as pd
import re
import sys



search_words = sys.argv[1:]
url = 'https://inf551-hw1-be0b2.firebaseio.com/index.json'
response = requests.get(url)
responsepy = json.loads(response.content)




key_dict = {'country': 'Code', 'city': 'ID', 'countrylanguage': 'Language'}




def search(search_list):
    #search_list = search_words.split(' ')
    result = {'country': [], 'city': [], 'countrylanguage': []}
    result_dict = {}
    for i in range(len(search_list)):
        search_list[i] = search_list[i].lower()
        search_list[i] = search_list[i].strip("[, \-!?:#$\./'\@&\()\,=\+\n]+")
        for t in responsepy[search_list[i]]:
            primary_key = key_dict[t['TABLE']]
            if t[primary_key] in result_dict:
                result_dict[t[primary_key]] = (result_dict[t[primary_key]][0] + 1,t['TABLE'])
            else:
                result_dict[t[primary_key]] = (1, t['TABLE'])
    sorted_list = sorted(result_dict.items(), key = lambda x: x[1][0], reverse=True)
    for t in sorted_list:
        result[t[1][1]].append(t[0])
    return result




print(search(search_words))








